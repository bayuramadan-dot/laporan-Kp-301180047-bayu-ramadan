-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 19 Mar 2022 pada 07.03
-- Versi server: 10.1.39-MariaDB
-- Versi PHP: 7.1.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_pust`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `anggota`
--

CREATE TABLE `anggota` (
  `no_anggota` int(20) NOT NULL,
  `nama_anggota` varchar(50) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `kelas` varchar(20) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `anggota`
--

INSERT INTO `anggota` (`no_anggota`, `nama_anggota`, `jenis_kelamin`, `kelas`, `alamat`) VALUES
(1, 'ALYA TRI DARMAWATI', 'perempuan', '3', 'KP. LEBAK GEDE\r\n'),
(2, 'DIMAS SATRIANSAH', 'laki-laki', '3', 'KP. LEBAK GEDE\r\n'),
(3, 'EVAN ZIGGY PRADIPTA', 'laki-laki', '3', 'KP. BABAKAN SAGU\r\n'),
(4, 'INTAN FATIMAH', 'perempuan', '3', 'KP. LEBAK GEDE\r\n'),
(5, 'ADE M. MIFTAHUDIN', 'laki-laki', '4', 'KP. LEBAKGEDE\r\n'),
(6, 'CITRA', 'perempuan', '4', 'KP. LEBAKGEDE\r\n'),
(7, 'DESTI AGUSTIN', 'perempuan', '4', 'KP. CIBUNTU\r\n'),
(8, 'AA BAHRUL ULUM', 'laki-laki', '5', 'KP. LEBAKGEDE\r\n'),
(9, 'AZAHRA AULIA', 'perempuan', '5', 'KP. CIBEET\r\n'),
(10, 'DIAN NURHASANAH', 'perempuan', '5', 'KP. CIBEET\r\n');

-- --------------------------------------------------------

--
-- Struktur dari tabel `buku`
--

CREATE TABLE `buku` (
  `no_buku` int(11) NOT NULL,
  `nama_buku` varchar(50) NOT NULL,
  `nama_pengarang` varchar(50) NOT NULL,
  `nama_penerbit` varchar(50) NOT NULL,
  `tahun_terbit` date NOT NULL,
  `jumlah_buku` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `buku`
--

INSERT INTO `buku` (`no_buku`, `nama_buku`, `nama_pengarang`, `nama_penerbit`, `tahun_terbit`, `jumlah_buku`) VALUES
(1, 'Membangun Kepribadian unggul satu hariku seri ke 1', 'Ipa Abong', 'Ipa Abong', '2010-02-09', '2'),
(2, 'Membangun Kepribadian unggul satu hariku seri ke 2', 'Ipa Abong', 'Ipa Abong', '2010-03-10', '2'),
(3, 'Membangun Kepribadian unggul satu hariku seri ke 3', 'Ipa Abong', 'Ipa Abong', '2011-03-16', '2'),
(4, 'aneka kreasi grafis pemula dengan corel draw', 'tiga serangkai', 'tiga serangkai', '2015-04-22', '2'),
(5, 'cerda dan cergas merancang sukses diri', 'tiga serangkai', 'tiga serangkai', '2015-07-20', '2'),
(6, 'dasar - dasar praktis microsoft excel', 'tiga serangkai', 'tiga serangkai', '2016-01-28', '2'),
(7, 'lebih cerdas dengan wikipedia', 'tiga serangkai', 'tiga serangkai', '2006-03-15', '2'),
(8, 'mengolah gambar sederhana dengan photoshop', 'tiga serangkai', 'tiga serangkai', '2010-01-05', '2'),
(9, 'raihlah bintang - bintang', 'nobel', 'nobel edumedia', '2008-03-26', '2'),
(10, 'panduan praktis berbusana', 'nobel', 'nobel edumedia', '2007-04-10', '2'),
(11, 'budidaya melon', 'nobel', 'nobel edumedia', '2011-03-08', '2');

-- --------------------------------------------------------

--
-- Struktur dari tabel `peminjaman`
--

CREATE TABLE `peminjaman` (
  `id_anggota` int(20) NOT NULL,
  `nama_anggota` varchar(30) NOT NULL,
  `nama_buku` varchar(20) NOT NULL,
  `tgl_pinjam` date NOT NULL,
  `tgl_kembali` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `peminjaman`
--

INSERT INTO `peminjaman` (`id_anggota`, `nama_anggota`, `nama_buku`, `tgl_pinjam`, `tgl_kembali`) VALUES
(1, 'ALYA TRI DARMAWATI', 'aneka kreasi grafis ', '2021-03-03', '2021-03-10'),
(2, 'DIMAS SATRIANSAH', 'cerda dan cergas mer', '2020-02-04', '2020-02-11'),
(3, 'EVAN ZIGGY PRADIPTA', 'Membangun Kepribadia', '2020-04-09', '2020-04-16'),
(4, 'INTAN FATIMAH', 'Membangun Kepribadia', '2021-02-02', '2021-02-09'),
(5, 'ADE M. MIFTAHUDIN', 'lebih cerdas dengan ', '2021-01-19', '2021-01-26'),
(7, 'DESTI AGUSTIN', 'cerda dan cergas mer', '2022-01-26', '2022-01-18');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `anggota`
--
ALTER TABLE `anggota`
  ADD PRIMARY KEY (`no_anggota`),
  ADD KEY `nama_anggota` (`nama_anggota`);

--
-- Indeks untuk tabel `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`no_buku`),
  ADD KEY `nama_buku` (`nama_buku`);

--
-- Indeks untuk tabel `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`id_anggota`),
  ADD KEY `nama_anggota` (`nama_anggota`),
  ADD KEY `nama_buku` (`nama_buku`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `anggota`
--
ALTER TABLE `anggota`
  MODIFY `no_anggota` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `buku`
--
ALTER TABLE `buku`
  MODIFY `no_buku` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `peminjaman`
--
ALTER TABLE `peminjaman`
  MODIFY `id_anggota` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
