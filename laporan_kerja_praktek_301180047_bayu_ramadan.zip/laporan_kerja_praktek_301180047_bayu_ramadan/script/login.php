<?php  
error_reporting(0);

session_start();

if(isset($_POST['login']) ) {

	$username = $_POST['username'];
	$password = $_POST['password'];

	if ($username =='admin' AND $password == 'admin') {
		session_start();
		$_SESSION['berhasil'] = true;


		header("Location: index.php");
	}else{
		$gagal = "<p style ='color:red;'>username dan password salah</p>";
	}
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Halaman Login</title>
<!DOCTYPE html>
<html>
<head>
	<title>Login perpustakaan</title>
</head>
<body>
	<style type="text/css">

body{
	font-family: arial;
	font-size: 14px;
	background-color: #222;
}

#utama{
	width: 400px;
	margin: 0 auto;
	margin-top: 10%;
}

#judul{
	padding: 50px;
	text-align: bottom;
	font-family: verdana;
	color: #fff;
	font-size: 20px;
	background-color: #0099ff;
	background-image: url(assets/img/pendidikan.png);
	background-position: top;
	background-size: 50%;
	background-repeat: no-repeat;
	border-top-right-radius: 5px;
	border-top-left-radius: 5px;
	border-bottom: 3px solid #336666;
	padding-top: 10px 
}

#inputan{
	background-color: #eaeaec;
	padding: 30px;
	border-bottom-right-radius: 10px;
	border-bottom-left-radius: 10px;
}

input{
	padding: 20px;
	border: 0;
}

.lg{
	width: 300px;
}

.btn{
	background-color: #0099ff;
	border-radius: 50px;
	color: #fff; 
	width: 350px;
}
.btn:hover{
	background-color: #005b8f;
	cursor: pointer;
}
body{ 
background-image: url(assets/img/background.jpg); 
background-size:100%;
background-attachment: fixed; } 
p{ color:white; } 
</style>	

<body>


<div id="utama">
	<div id="judul"> 
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<p align="center">APLIKASI PERPUSTAKAAN</p>
	</div>

	<div id="inputan">
	<form action="" method="post">
		<?php echo $gagal; ?>
		<div>
			<input type="text" name="username" placeholder="username" class="lg" required="">
		</div>
		<div style="margin-top: 10px">
			<input type="text" name="password" placeholder="password" class="lg" required="">
		</div>
		<div style="margin-top: 15px">
			<button type="submit" name="login" class="btn">LOGIN</button> 
		</div>
	</form>


</body>
</html>

</head>
</html>