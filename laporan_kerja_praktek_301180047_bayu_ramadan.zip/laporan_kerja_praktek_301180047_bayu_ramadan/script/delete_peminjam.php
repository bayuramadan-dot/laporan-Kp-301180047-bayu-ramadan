 <?php include 'koneksi.php'; ?>
<?php 
	$koneksi->query("DELETE FROM  peminjaman WHERE id_anggota='$_GET[id_anggota]'");

	 echo "<script>alert('Data Peminjam Berhasil Di hapus')</script>";
     echo "<script>location='data_peminjam.php';</script>";
 ?>