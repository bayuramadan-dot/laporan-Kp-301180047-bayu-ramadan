  <?php include 'koneksi.php' ?>
   <?php include 'head.php' ;?>
      <?php include 'menu.php' ;?>
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Update Data</h2>   
                    </div>
                </div>              
                  <hr />  
                  <div>
                        <?php 
                      $tampil_data = $koneksi->query("SELECT * FROM anggota WHERE no_anggota='$_GET[no_anggota]'");
                      $detail_anggota = $tampil_data->fetch_assoc();
                     ?>
                      <form method="post">
                      <div class="row col-md-8">
                         <label>No. Anggota</label>
                          <input type="text" name="no_anggota" class="form-control" value="<?php echo $detail_anggota['no_anggota']; ?>">
                          <label>Nama Anggota</label>
                          <input type="text" name="nama_anggota" class="form-control" value="<?php echo $detail_anggota['nama_anggota']; ?>">
                          <label>Jenis Kelamin</label>
                          <select name="jenis_kelamin" class="form-control" >
                          <option value="">-PILIH-</option>
                          <option value="laki-laki">laki-laki</option>
                          <option value="perempuan">Perempuan</option>
                          </select>
                          <label>Kelas</label>
                          <input type="text" name="kelas" class="form-control" value="<?php echo $detail_anggota['kelas']; ?>">
                          <label>Alamat</label>
                          <textarea name="alamat" class="form-control" ><?php echo $detail_anggota['alamat']; ?></textarea>
                          <button type="submit" class="btn btn-primary" name="Update">Simpan</button>
                      </div>
                    </form>
                    <?php 
                      if (isset($_POST['Update'])) 
                      {
                        $koneksi->query(" UPDATE anggota SET no_anggota='$_POST[no_anggota]',nama_anggota='$_POST[nama_anggota]',jenis_kelamin ='$_POST[jenis_kelamin]',kelas ='$_POST[kelas]',alamat ='$_POST[alamat]' WHERE no_anggota='$_GET[no_anggota]'");

                          echo "<script>alert('Data Anggota Berhasil Di Ubah')</script>";
                          echo "<script>location='data_anggota.php';</script>";
                      }
                     ?>
                  </div>      
                </div>
            </div>
<?php include 'js.php' ;?>
