  <?php 
    session_start();
    if (!$_SESSION['berhasil']) {
      header("location:login.php");
      die();
    }
 ?>
<?php include 'koneksi.php' ;?>
<?php include 'head.php' ;?>
               <?php include 'menu.php' ;?>
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>HALAMAN DATA PEMINJAMAN</h2>   
                    </div>
                </div>              
                  <hr /> 
                   <div>
                     <div class="panel panel-default">
                        <div class="panel-heading">
                             <a href="input_peminjam.php"><button type="submit" class="btn btn-success">Tambah Data</button></a>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr><?php $nomor=1; ?>
                                            <th>No.</th>
                                            <th>No. Anggota</th>
                                            <th>Nama Peminjam</th>
                                            <th>Judul Buku</th>
                                            <th>Tangal pinjam</th>
                                            <th>Tanggal kembali</th>
                                            <th>Opsi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $tampil_data = $koneksi->query("SELECT * FROM peminjaman");  ?>
                                      <?php while ( $peminjaman = $tampil_data->fetch_assoc()){ ?>
                                        <tr class="">
                                            <td><?php echo $nomor; ?></td>
                                            <td>00<?php echo $peminjaman ['id_anggota']; ?></td>
                                            <td><?php echo $peminjaman ['nama_anggota']; ?></td>
                                            <td><?php echo $peminjaman ['nama_buku']; ?></td>
                                            <td><?php echo $peminjaman ['tgl_pinjam']; ?></td>
                                            <td><?php echo $peminjaman ['tgl_kembali']; ?></td>
                                            <td>
                                              <a href="delete_peminjam.php?id_anggota=<?php echo $peminjaman['id_anggota'];?>"><button type="submit" class="btn btn-danger">Hapus</button></a>
                                              <a href="edit_peminjam.php?id_anggota=<?php echo $peminjaman['id_anggota'];?>"><button type="submit" class="btn btn-warning">Ubah</button></a>
                                            </td>
                                        </tr> 
                                        <?php $nomor++; ?>
                                      <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                  </div>      
                </div>
            </div>
<?php include 'js.php' ;?>
