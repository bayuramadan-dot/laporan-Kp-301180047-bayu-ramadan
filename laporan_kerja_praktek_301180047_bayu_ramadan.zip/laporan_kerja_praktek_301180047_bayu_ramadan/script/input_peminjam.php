  <?php 
    session_start();
    if (!$_SESSION['berhasil']) {
      header("location:login.php");
      die();
    }
 ?>
<?php include 'koneksi.php' ?>
<?php include 'head.php' ;?>
               <?php include 'menu.php' ;?>
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>HALAMAN TAMBAH DATA PEMINJAM</h2>   
                    </div>
                </div>              
                  <hr />   
                    <div>
                    <form method="post">
                      <div class="row col-md-8">
                         <label>No. Anggota</label>
                         <select name="id_anggota" class="form-control">
                           <option value="">-PILIH-</option>
                           <?php $tampil_data = $koneksi->query("SELECT * FROM anggota");  ?>
                                      <?php while ( $anggota = $tampil_data->fetch_assoc()){ ?>
                           <option value="<?php echo $anggota['no_anggota']; ?>"><?php echo $anggota['no_anggota']; ?></option>
                         <?php } ?>
                         </select> 
                          <label>Nama Anggota</label>
                          <select name="nama_anggota" class="form-control">
                           <option value="">-PILIH-</option>
                           <?php $tampil_data = $koneksi->query("SELECT * FROM anggota");  ?>
                                      <?php while ( $anggota = $tampil_data->fetch_assoc()){ ?>
                           <option value="<?php echo $anggota['nama_anggota']; ?>"><?php echo $anggota['nama_anggota']; ?></option>
                         <?php } ?>
                         </select> 
                          <label>Judul Buku</label>
                          <select name="nama_buku" class="form-control">
                           <option value="">-PILIH-</option>
                           <?php $tampil_data = $koneksi->query("SELECT * FROM buku");  ?>
                                      <?php while ( $buku = $tampil_data->fetch_assoc()){ ?>
                           <option value="<?php echo $buku['nama_buku']; ?>"><?php echo $buku['nama_buku']; ?></option>
                         <?php } ?>
                         </select> 
                          <label>Tanggal Pinjam</label>
                          <input type="date" name="tgl_pinjam" class="form-control" placeholder="Masukan Tanggal" required="">
                          <label>Tanggal kembali</label>
                          <input type="date" name="tgl_kembali" class="form-control" placeholder="Masukan Tanggal" required="">
                          <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
                      </div>
                    </form>
                    <?php 
                        if (isset ($_POST['simpan']))
                        {
                          $id_anggota = $_POST["id_anggota"];
                          $nama_anggota = $_POST["nama_anggota"];
                          $nama_buku = $_POST["nama_buku"];
                          $tgl_pinjam = $_POST["tgl_pinjam"];
                          $tgl_kembali = $_POST["tgl_kembali"];

                                 $koneksi->query(" INSERT INTO peminjaman (id_anggota, nama_anggota, nama_buku, tgl_pinjam, tgl_kembali)VALUES
                              ('$id_anggota','$nama_anggota','$nama_buku','$tgl_pinjam','$tgl_kembali')");

                            echo "<script>alert('Data Peminjam Berhasil Disimpan')</script>";
                            echo "<script>location='data_peminjam.php';</script>";
                        }
                     ?>
                  </div>            
                </div>
            </div>
<?php include 'js.php' ;?>
