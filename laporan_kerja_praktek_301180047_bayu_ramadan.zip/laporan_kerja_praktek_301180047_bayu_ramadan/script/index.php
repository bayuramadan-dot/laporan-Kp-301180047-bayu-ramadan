<?php 
    session_start();
    if (!$_SESSION['berhasil']) {
      header("location:login.php");
      die();
    }
 ?>
<?php include 'koneksi.php' ?>
	<?php include 'head.php' ;?>
         <?php include 'menu.php' ;?>
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>SELAMAT DATANG DI PERPUSTAKAAN SDN PASIRBITUNG</h2>   
                    </div>
                </div>              
                <hr />
                <div class ="row">          
            <div class="panel panel-back noti-box">
                <div class="right">
                <span class="icon-box bg-color-green set-icon">
                    <i class="fa fa-thumb-tack"></i>
                </span>
                <div class="text-box" >
                    <u><p class="main-text">Sejarah Singkat</p></u>
                    <p class="text-muted" align="justify">Sejarah perpustakaan di Indonesia tergolong masih muda jika dibandingkan dengan negara Eropa dan Arab. Jika kita mengambil pendapat bahwa sejarah perpustakaan ditandai dengan dikenalnya tulisan, maka sejarah perpustakaan di Indonesia dapat dimulai pada tahun 400-an yaitu saat lingga batu dengan tulisan Pallawa ditemukan dari periode Kerajaan Kutai. Musafir Fa-Hsien dari tahun 414 Menyatakan bahwa di kerajaan Ye-po-ti, yang sebenarnya kerajaan Tarumanegara banyak dijumpai kaum Brahmana yang tentunya memerlukan buku atau manuskrip keagamaan yang mungkin disimpan di kediaman pendeta.</p>
                </div>
                </div>
            </div>
             </div>
         </div> 
<?php include 'js.php' ?>