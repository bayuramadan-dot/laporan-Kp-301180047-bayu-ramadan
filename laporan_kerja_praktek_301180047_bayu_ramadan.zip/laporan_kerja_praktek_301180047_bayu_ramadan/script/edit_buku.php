<?php include 'koneksi.php' ?>
<?php include 'head.php' ;?>
               <?php include 'menu.php' ;?>
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Update Data</h2>   
                    </div>
                </div>              
                  <hr /> 
                   <?php 
                      $tampil_data = $koneksi->query("SELECT * FROM buku WHERE no_buku='$_GET[no_buku]'");
                      $detail_buku = $tampil_data->fetch_assoc();
                     ?>  
                     <div>
                    <form method="post">
                      <div class="row col-md-8">
                        <label>No. Buku</label>
                          <input type="text" name="no_buku" class="form-control" readonly="" value="<?php echo $detail_buku['no_buku']; ?>">
                          <label>Judul Buku</label>
                          <input type="text" name="nama_buku" class="form-control" value="<?php echo $detail_buku['nama_buku']; ?>">
                             <label>Nama Pengarang</label>
                          <input type="text" name="nama_pengarang" class="form-control" value="<?php echo $detail_buku['nama_pengarang']; ?>">
                          <label>Nama Penerbit</label>
                          <input type="text" name="nama_penerbit" class="form-control" value="<?php echo $detail_buku['nama_penerbit']; ?>">                 
                             <label>Tahun Terbit</label>
                          <input type="date" name="tahun_terbit" class="form-control" value="<?php echo $detail_buku['tahun_terbit']; ?>">
                            <label>Jumlah Buku</label>
                          <input type="text" name="jumlah_buku" class="form-control" value="<?php echo $detail_buku['jumlah_buku']; ?>">
                          <button type="submit" class="btn btn-primary" name="Update">Simpan</button>
                      </div>
                    </form>
                     <?php 
                      if (isset($_POST['Update'])) 
                      {
                        $koneksi->query(" UPDATE buku SET nama_buku='$_POST[nama_buku]',nama_pengarang ='$_POST[nama_pengarang]',nama_penerbit ='$_POST[nama_penerbit]',tahun_terbit ='$_POST[tahun_terbit]',jumlah_buku='$_POST[jumlah_buku]' WHERE no_buku='$_GET[no_buku]'");

                          echo "<script>alert('Data Buku Berhasil Di Ubah')</script>";
                          echo "<script>location='data_buku.php';</script>";
                      }
                     ?>      
                </div>
            </div>
<?php include 'js.php' ;?>
