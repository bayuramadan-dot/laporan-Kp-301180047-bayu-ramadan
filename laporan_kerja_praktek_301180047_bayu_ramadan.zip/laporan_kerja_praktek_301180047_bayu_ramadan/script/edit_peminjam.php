 <?php include 'koneksi.php' ?>
<?php include 'head.php' ;?>
               <?php include 'menu.php' ;?>
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Update Data</h2>   
                    </div>
                </div>              
                  <hr /> 
                   <?php 
                      $tampil_data = $koneksi->query("SELECT * FROM peminjaman WHERE id_anggota='$_GET[id_anggota]'");
                      $detail_peminjaman = $tampil_data->fetch_assoc();
                     ?>  
                     <div>
                    <form method="post">
                      <div class="row col-md-8">
                         <label>No. Anggota</label>
                          <input type="text" name="id_anggota" class="form-control" readonly="" value="<?php echo $detail_peminjaman['id_anggota']; ?>">
                          <label>Nama Peminjam</label>
                          <input type="text" name="nama_anggota" class="form-control" value="<?php echo $detail_peminjaman['nama_anggota']; ?>">
                          <label>Judul Buku</label>
                           <input type="text" name="nama_buku" class="form-control" value="<?php echo $detail_peminjaman['nama_buku']; ?>">
                          <label>Tanggal Pinjam</label>
                          <input type="text" name="tgl_pinjam" class="form-control" value="<?php echo $detail_peminjaman['tgl_pinjam']; ?>">
                             <label>Tanggal Kembali</label>
                          <input type="text" name="tgl_kembali" class="form-control" value="<?php echo $detail_peminjaman['tgl_kembali']; ?>">
                          <button type="submit" class="btn btn-primary" name="Update">Update</button>
                      </div>
                    </form>
                     <?php 
                      if (isset($_POST['Update'])) 
                      {
                        $koneksi->query(" UPDATE peminjaman SET id_anggota='$_POST[id_anggota]',nama_anggota='$_POST[nama_anggota]',nama_buku ='$_POST[nama_buku]',tgl_pinjam ='$_POST[tgl_pinjam]',tgl_kembali ='$_POST[tgl_kembali]' WHERE id_anggota='$_GET[id_anggota]'");

                          echo "<script>alert('Data Peminjam Berhasil Di Ubah')</script>";
                          echo "<script>location='data_peminjam.php';</script>";
                      }
                     ?>      
                </div>
            </div>
<?php include 'js.php' ;?>
