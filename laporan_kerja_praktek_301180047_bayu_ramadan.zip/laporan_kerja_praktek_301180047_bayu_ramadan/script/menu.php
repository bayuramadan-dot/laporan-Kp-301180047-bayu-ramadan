<nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="assets/img/pendidikan.png" class="user-image img-responsive"/>
					</li>
                    <li>
                        <a class="active-menu"  href="index.php"><i class="fa fa-home fa-3x"></i> Beranda</a>
                    </li>
                    <li>
                        <a  href="data_anggota.php"><i class="fa fa-user fa-3x"></i>Anggota</a>
                    </li>
                      <li  >
                        <a  href="data_buku.php"><i class="fa fa-book fa-3x"></i>Buku</a>
                    </li>
                    <li  >
                        <a  href="data_peminjam.php"><i class="fa fa-book fa-3x"></i>Peminjaman Buku</a>
                    </li>
                    <li>
                        <a  href="Logout.php"><i class="fa fa-sign-out fa-3x"></i>Log Out</a>
                    </li>	
                </ul>
               
            </div>
            
        </nav>  