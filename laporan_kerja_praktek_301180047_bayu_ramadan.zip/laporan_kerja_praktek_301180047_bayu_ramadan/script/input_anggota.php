<?php 
    session_start();
    if (!$_SESSION['berhasil']) {
      header("location:login.php");
      die();
    }
 ?>
<?php include 'koneksi.php' ?>
<?php include 'head.php' ;?>
               <?php include 'menu.php' ;?>
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>HALAMAN TAMBAH DATA ANGGOTA</h2>   
                    </div>
                </div>              
                  <hr />    
                  <div>
                    <form method="post">
                      <div class="row col-md-8">
                          <label>Nama Anggota</label>
                          <input type="text" name="nama_anggota" class="form-control" placeholder="Masukan Nama Anggota" required="">
                          <label>Jenis Kelamin</label>
                          <select name="jenis_kelamin" class="form-control" >
                          <option value="">-PILIH-</option>
                          <option value="laki-laki">laki-laki</option>
                          <option value="perempuan">Perempuan</option>
                          </select>
                          <label>kelas</label>
                          <input type="text" name="kelas" class="form-control" placeholder="Masukan kelas" required="">
                          <label>Alamat</label>
                          <textarea name="alamat" class="form-control" placeholder="Masukan Alamat" ></textarea>
                          <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
                      </div>
                    </form>
                    <?php 
                        if (isset ($_POST['simpan']))
                        {
                          $nama_anggota = $_POST["nama_anggota"];
                          $jenis_kelamin = $_POST["jenis_kelamin"];
                          $kelas = $_POST["kelas"];
                          $alamat = $_POST["alamat"];

                                 $koneksi->query(" INSERT INTO anggota (nama_anggota, jenis_kelamin, kelas, alamat)VALUES ('$nama_anggota','$jenis_kelamin','$kelas','$alamat')");

                            echo "<script>alert('Data Anggota Berhasil Disimpan')</script>";
                            echo "<script>location='data_anggota.php';</script>";
                        }
                     ?>
                </div>
            </div>
<?php include 'js.php' ;?>
