<?php 
    session_start();
    if (!$_SESSION['berhasil']) {
      header("location:login.php");
      die();
    }
 ?>
<?php include 'koneksi.php' ?>
<?php include 'head.php' ;?> 
               <?php include 'menu.php' ;?>
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>HALAMAN TAMBAH DATA BUKU</h2>   
                    </div>
                </div>              
                    <hr /> 
                   <div>
                    <form method="post">
                      <div class="row col-md-8">
                          <label>Judul Buku</label>
                          <input type="text" name="nama_buku" class="form-control" placeholder="Masukan Judul Buku" required="">
                           <label>Nama Pengarang</label>
                          <input type="text" name="nama_pengarang" class="form-control" placeholder="Masukan Nama Pengarang" required="">
                          <label>Nama Penerbit</label>
                            <input type="text" name="nama_penerbit" class="form-control" placeholder="Masukan Nama Penerbit" required="">
                          <label>Tahun terbit</label>
                          <input type="date" name="tahun_terbit" class="form-control" placeholder="Masukan tahun Terbit" required="">  
                          <label>Jumlah Buku</label>
                          <input type="text" name="jumlah_buku" class="form-control" placeholder="Masukan Jumlah Buku" required="">                
                          <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
                      </div>
                    </form> 
                    <?php 
                      if (isset ($_POST['simpan'])) 
                      {
                        $nama_buku=$_POST['nama_buku'];
                        $nama_pengarang=$_POST['nama_pengarang'];
                        $nama_penerbit=$_POST['nama_penerbit'];
                        $tahun_terbit=$_POST['tahun_terbit'];
                        $jumlah_buku=$_POST['jumlah_buku'];

                        $koneksi->query(" INSERT INTO buku (nama_buku, nama_pengarang, nama_penerbit, tahun_terbit, jumlah_buku) VALUES ('$nama_buku','$nama_pengarang', '$nama_penerbit','$tahun_terbit', '$jumlah_buku')");

                        echo "<script>alert('Data Buku Berhasil Disimpan')</script>";
                            echo "<script>location='data_buku.php';</script>";
                      }

                     ?>     
                </div>
            </div>
<?php include 'js.php' ;?>
