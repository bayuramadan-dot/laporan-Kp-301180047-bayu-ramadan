 <?php 
    session_start();
    if (!$_SESSION['berhasil']) {
      header("location:login.php");
      die();
    }
 ?>
<?php include 'koneksi.php' ;?>
    <?php include 'head.php' ;?>
      <?php include 'menu.php' ;?>
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>HALAMAN DATA BUKU</h2>   
                    </div>
                </div>              
                  <hr />        
                  <div>
                     <div class="panel panel-default">
                        <div class="panel-heading">
                            <a href="input_buku.php"><button type="submit" class="btn btn-success">Tambah Data</button></a>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr><?php $nomor=1; ?>
                                            <th>No.</th>
                                            <th>No. Buku</th>
                                            <th>Judul Buku</th>
                                            <th>Nama Pengarang</th>
                                            <th>Nama Penerbit</th>
                                            <th>Tahun Terbit</th>
                                            <th>Jumlah Buku</th>
                                            <th>Opsi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $tampil_data = $koneksi->query("SELECT * FROM buku");  ?>
                                      <?php while ( $buku = $tampil_data->fetch_assoc()){ ?>
                                        <tr class="">
                                            <td><?php echo $nomor; ?></td>
                                            <td>00<?php echo $buku ['no_buku']; ?></td>
                                            <td><?php echo $buku ['nama_buku']; ?></td>
                                            <td><?php echo $buku ['nama_pengarang']; ?></td>
                                            <td><?php echo $buku ['nama_penerbit']; ?></td>
                                            <td><?php echo $buku ['tahun_terbit']; ?></td>
                                            <td><?php echo $buku ['jumlah_buku']; ?></td>
                                            <td>
                                              <a href="delete_buku.php?no_buku=<?php echo $buku['no_buku'];?>"><button type="submit" class="btn btn-danger">Hapus</button></a>
                                              <a href="edit_buku.php?no_buku=<?php echo $buku['no_buku'];?>"><button type="submit" class="btn btn-warning">Ubah</button></a>
                                            </td>
                                        </tr> 
                                        <?php $nomor++; ?>
                                      <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                  </div>
                </div>
            </div>
<?php include 'js.php' ;?>
