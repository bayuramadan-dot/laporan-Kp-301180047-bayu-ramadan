 <?php include 'koneksi.php'; ?>
<?php 
	$koneksi->query("DELETE FROM  anggota WHERE no_anggota='$_GET[no_anggota]'");

	 echo "<script>alert('Data Anggota Berhasil Di hapus')</script>";
     echo "<script>location='data_anggota.php';</script>";
 ?>