<?php include 'koneksi.php'; ?>
<?php 
	$koneksi->query("DELETE FROM  buku WHERE no_buku='$_GET[no_buku]'");

	 echo "<script>alert('Data buku Berhasil Di hapus')</script>";
     echo "<script>location='data_buku.php';</script>";
 ?>